-- Create Database
CREATE DATABASE Employee_Management;
 
-- Create User_Department Table with Auto-Incrementing deptid
CREATE TABLE user_department (
    deptid INT PRIMARY KEY IDENTITY(1,1),  -- Auto-incrementing primary key
    deptname VARCHAR(MAX) NOT NULL,
    username VARCHAR(255) NOT NULL,  -- Assuming username is unique
    userpswd VARCHAR(255) NOT NULL
);
 
-- Create Employee Table Referencing deptid from User_Department
CREATE TABLE employee (
    empid INT PRIMARY KEY NOT NULL,
    fname VARCHAR(MAX) NOT NULL,
    lname VARCHAR(MAX) NOT NULL,
    dob DATE NOT NULL,
    doj DATE NOT NULL,
    deptid INT FOREIGN KEY REFERENCES user_department(deptid),  -- Foreign key reference
    grade VARCHAR(MAX) NOT NULL,
    designation VARCHAR(MAX) NOT NULL,
    basicsal INT NOT NULL,
    gender VARCHAR(MAX) NOT NULL,
    maritalstatus VARCHAR(MAX) NOT NULL,
    homeaddress VARCHAR(MAX) NOT NULL,
    contactno INT NOT NULL
);
 
-- Create Grade Table
CREATE TABLE grade (
    gradecode INT PRIMARY KEY NOT NULL,
    descript VARCHAR(MAX) NOT NULL,
);
drop table grade
drop table employee

select * from user_department
select * from employee
