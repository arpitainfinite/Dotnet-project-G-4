﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace adminpage.Models
{
    public class AgeValidationAttribute : ValidationAttribute
    {
        public readonly int _minAge;
        public readonly int _maxAge;

        public AgeValidationAttribute(int minAge, int maxAge)
        {
            _minAge = minAge;
            _maxAge = maxAge;
            ErrorMessage = $"Age must be between {minAge} and {maxAge} years :-) ";
        }

        public override bool IsValid(object value)
        {
            if (value == null) return false;
            var dob = (DateTime)value;
            var age = DateTime.Today.Year - dob.Year;
            if (dob.Date > DateTime.Today.AddYears(-age)) age--;
            return age >= _minAge && age <= _maxAge;
        }
    }
}