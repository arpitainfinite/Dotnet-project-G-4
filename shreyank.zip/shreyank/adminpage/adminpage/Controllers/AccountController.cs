﻿using System.Web.Mvc;

namespace adminpage
{
    public class AccountController : Controller
    {
        // GET: Account/SignIn
        public ActionResult SignIn()
        {
            // Return a blank SignIn view
            return View();
        }

        // POST: Account/Logout
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Logout()
        {
            // Perform the logout logic, e.g., clear the session
            Session.Clear();
            // Redirect to the SignIn page
            return RedirectToAction("SignIn");
        }
    }
}
