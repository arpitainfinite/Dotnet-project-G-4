﻿using System.Web.Mvc;

namespace adminpage
{
    public class HomeController : Controller
    {
        // GET: Home/Index
        public ActionResult Index()
        {
            return View();
        }
    }
}

