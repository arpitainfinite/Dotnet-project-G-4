﻿using System.Web.Mvc;
using adminpage.Models;

namespace adminpage
{
    public class DepartmentController : Controller
    {
        // GET: Department/Register
        public ActionResult New()
        {
            return View();
        }
        public ActionResult details()
        {
            return View();
        }
        [HttpPost]
        public ActionResult details(user_department model)
        {
            using (Employee_ManagementEntities2 entities = new Employee_ManagementEntities2())
            {
                entities.user_department.Add(model);

                entities.SaveChanges();
            }
            return RedirectToAction("Employee");
        }


    }
}
