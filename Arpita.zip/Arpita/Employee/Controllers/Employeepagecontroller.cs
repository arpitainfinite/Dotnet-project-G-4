﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Employee.Models;
using System.Web.Security;



namespace Employee
{
    public class EmployeeController : Controller
    {
        [HttpGet]
        public ActionResult NewEmployee()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult NewEmployee(employee employee)
        {

            using (Employee_ManagementsEntities entities = new Employee_ManagementsEntities())
            {
                entities.employees.Add(employee);
                entities.SaveChanges();
            }
            return RedirectToAction("Login");


            //if (ModelState.IsValid)
            //{
            //    // Save the employee to the database or perform other actions
            //    return RedirectToAction("Index"); // Redirect to the main page or confirmation page
            //}
            //return View(employee);
        }
       
    }

}


