﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Employee.Models
{

    public partial class employee
    {
        public int empid { get; set; }
        [Required]
        [Display(Name = "First Name")]
        [RegularExpression(@"^[A-Z][a-zA-Z]*$", ErrorMessage = "First letter must be capitalized.")]
        public string fname { get; set; }
        [Required]
        [Display(Name = "Last Name")]
        [RegularExpression(@"^[A-Z][a-zA-Z]*$", ErrorMessage = "First letter must be capitalized.")]
        public string lname { get; set; }
        [Required]
        [AgeValidation(18, 58, ErrorMessage = "Age must be between 18 and 58 years.")]
        [Display(Name = "Date of Birth")]
        public System.DateTime dob { get; set; }
        [Display(Name = "Date of Joining")]
        [Required]
        public System.DateTime doj { get; set; }

        [Required]

        [Display(Name = "Department ID")]
        public int deptid { get; set; }



        //public virtual user_department Userdepartment { get; set; }
        //// public Nullable<int> deptid { get; set; }
        [Required]
        public string grade { get; set; }
        [Required]
        public string designation { get; set; }
        [Required]
        public int basicsal { get; set; }
        [Required]
        public string gender { get; set; }
        [Required]
        public string maritalstatus { get; set; }
        [Required]
        public string homeaddress { get; set; }
        [Required]
        [StringLength(100, ErrorMessage = "Address cannot exceed 100 characters.")]
        public int contactno { get; set; }
        [Required]


    }
        public virtual user_department department { get; set; }

    }
