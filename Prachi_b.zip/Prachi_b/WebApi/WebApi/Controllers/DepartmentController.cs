﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using WebApi.Models;

namespace WebApi.Controllers
{
    public class DepartmentController : ApiController
    {
        private Employee_ManagementEntities db = new Employee_ManagementEntities();

        // GET: api/Department
        public IQueryable<user_department> Getuser_department()
        {
            return db.user_department;
        }

        // GET: api/Department/5
        [ResponseType(typeof(user_department))]
        public IHttpActionResult Getuser_department(string id)
        {
            user_department user_department = db.user_department.Find(id);
            if (user_department == null)
            {
                return NotFound();
            }

            return Ok(user_department);
        }

        // PUT: api/Department/5
        [ResponseType(typeof(void))]
        public IHttpActionResult Putuser_department(string id, user_department user_department)
        {
            

            if (id != user_department.username)
            {
                return BadRequest();
            }

            db.Entry(user_department).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!user_departmentExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Department
        [ResponseType(typeof(user_department))]
        public IHttpActionResult Postuser_department(user_department user_department)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.user_department.Add(user_department);

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateException ex)
            {
                if (user_departmentExists(user_department.username))
                {
                    return Conflict();
                }
                else
                {
                    // Log the exception (using a logging framework or your own logging mechanism)
                    // For example:
                    //Log.Error(ex, "An error occurred while saving a new department.");
                    return InternalServerError(ex);
                }
            }

            // Return a 201 Created response, with the route to get the new department and the department itself in the body
            return CreatedAtRoute("DefaultApi", new { id = user_department.username }, user_department);
        }


        // DELETE: api/Department/5
        [ResponseType(typeof(user_department))]
        public IHttpActionResult Deleteuser_department(string id)
        {
            user_department user_department = db.user_department.Find(id);
            if (user_department == null)
            {
                return NotFound();
            }

            db.user_department.Remove(user_department);
            db.SaveChanges();

            return Ok(user_department);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool user_departmentExists(string id)
        {
            return db.user_department.Count(e => e.username == id) > 0;
        }
    }
}