﻿using System.Web.Mvc;
using MVC.Models;
using System.Threading.Tasks;
using System.Net.Http;

namespace MVC.Controllers
{
    public class DepartmentController : Controller
    {
        // GET: Department/New
        public ActionResult New()
        {
            return View();
        }

        [HttpPost]
        public async Task<ActionResult> Create(MVCDepartmentModel model)
        {
            if (ModelState.IsValid)
            {
                HttpResponseMessage response = null;
                try
                {
                    response = await GlobalVariables.WebApiClient.PostAsJsonAsync("user_department", model);
                }
                catch (HttpRequestException ex)
                {
                    // Log the exception details and handle accordingly
                    // e.g., Log.Error(ex, "Error contacting the API.");
                    ModelState.AddModelError(string.Empty, "There was a problem contacting the server.");
                    return View("New", model);
                }

                if (response.IsSuccessStatusCode)
                {
                    TempData["SuccessMessage"] = "Department added successfully";
                    return RedirectToAction("New");
                }
                else
                {
                    // Log the error response and handle accordingly
                    // e.g., Log.Warning($"API call failed: {response.ReasonPhrase}");
                    ModelState.AddModelError(string.Empty, $"Server error. Please contact administrator. Status: {response.StatusCode}");
                }
            }

            // If we got this far, something failed; redisplay form
            return View("New", model);
        }


    }
}

