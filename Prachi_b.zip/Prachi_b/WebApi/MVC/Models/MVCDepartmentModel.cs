﻿using System.ComponentModel.DataAnnotations;
using System.Text.RegularExpressions;

namespace MVC.Models
{
    public class MVCDepartmentModel
    {
        

        [Required(ErrorMessage = "Department name is required.")]
        [StringLength(50, ErrorMessage = "Department name cannot exceed 50 characters.")]
        [RegularExpression(@"^\S*$", ErrorMessage = "No white space allowed in department name.")]
        public string deptname { get; set; }

        [Required(ErrorMessage = "Username is required.")]
        [StringLength(30, ErrorMessage = "Username cannot exceed 30 characters.")]
        [RegularExpression(@"^\S*$", ErrorMessage = "No white space allowed in username.")]
        public string username { get; set; }

        [Required(ErrorMessage = "Password is required.")]
        [DataType(DataType.Password)]
        [StringLength(100, ErrorMessage = "Password must be between 6 and 100 characters.", MinimumLength = 6)]
        [RegularExpression(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{6,100}$", ErrorMessage = "Password must be 6 to 100 characters and include at least one uppercase letter, one lowercase letter, and one number.")]
        public string userpswd { get; set; }
    }
}
